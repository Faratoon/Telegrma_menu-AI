# 🤖 ALL-IN-ONE TELEGRAM BOT

Dhamaantood isku noqdaan bot mid!

## Features ✨

- 💬 **AI Chat** - Hadal Gemini AI
- 📝 **Create Posts** - Qor ama AI generate
- 📢 **Multipost** - Diriri labadan channel
- 📤 **Forward Messages** - Forward between channels
- ⏰ **Schedule Posts** - Qorshee posts
- 🎓 **Learning Mode** - Baro topics
- ✍️ **Creative Writing** - Create content

## Setup 🚀

### 1. Get Tokens
- **Telegram**: Message @BotFather, send `/newbot`
- **Gemini**: Go to https://makersuite.google.com/app/apikeys

### 2. Install
```bash
pip install -r requirements.txt
```

### 3. Configure
Edit `config/settings.py`:
```python
TELEGRAM_TOKEN = "your_token"
GEMINI_API_KEY = "your_key"
CHANNELS = {
    "news": -1001234567890,
    "updates": -1001234567891,
}
```

### 4. Run
```bash
python src/main.py
```

## Folder Structure 📁

```
telegram-ai-bot/
├── src/
│   └── main.py           # Main bot code
├── config/
│   └── settings.py       # Configuration
├── logs/                 # Bot logs
├── data/                 # User data
├── requirements.txt      # Dependencies
├── .env.example          # Environment template
├── .gitignore           # Git ignore
└── README.md            # This file
```

## How to Use 📖

1. Start bot: `/start`
2. Choose option from menu
3. Follow instructions
4. Done! ✅

## Support 💬

Having issues? 
- Check `logs/bot.log`
- Review `config/settings.py`
- Make sure tokens are correct

## License 📄

Free to use!

---

**Created by**: Caawiyebot
**Version**: 1.0.0