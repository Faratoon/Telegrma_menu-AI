import logging
import asyncio
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from datetime import datetime, timedelta

# Enable logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", 
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Configure your channels here (add channel IDs)
CHANNELS = {
    "news": -1001234567890,      # Replace with your channel ID
    "updates": -1001234567891,   # Replace with your channel ID
    "announcements": -1001234567892  # Replace with your channel ID
}

# Store messages to forward
message_queue = {}

# ============ COMMAND HANDLERS ============

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start command - show available commands"""
    help_text = """
🤖 **Telegram Multi-Channel Bot Commands:**

/start - Show this help message
/post <text> - Post a message to all channels
/post_channel <channel_name> <text> - Post to specific channel
/forward <channel_from> <channel_to> - Forward latest message between channels
/schedule <seconds> <text> - Schedule a message (in seconds)
/list_channels - Show all configured channels
/help - Show detailed help

**Channel Names:** news, updates, announcements

Example:
/post Hello everyone!
/post_channel news Breaking news here!
/schedule 30 This message sends in 30 seconds!
    """
    await update.message.reply_text(help_text, parse_mode="Markdown")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Help command"""
    await start(update, context)

async def list_channels(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """List all available channels"""
    channels_list = "\n".join([f"• {name}" for name in CHANNELS.keys()])
    await update.message.reply_text(f"📢 **Available Channels:**\n{channels_list}", parse_mode="Markdown")

# ============ POSTING HANDLERS ============

async def post_to_all(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/post <text> - Post message to all channels"""
    if not context.args:
        await update.message.reply_text("❌ Usage: /post <your message>")
        return
    
    message_text = " ".join(context.args)
    
    try:
        for channel_name, channel_id in CHANNELS.items():
            await context.bot.send_message(
                chat_id=channel_id,
                text=f"📢 {message_text}\n\n*(Sent by bot)*",
                parse_mode="Markdown"
            )
        await update.message.reply_text("✅ Message posted to all channels!")
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")
        logger.error(f"Error posting to channels: {e}")

async def post_to_channel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/post_channel <channel> <text> - Post to specific channel"""
    if len(context.args) < 2:
        await update.message.reply_text("❌ Usage: /post_channel <channel_name> <message>")
        return
    
    channel_name = context.args[0].lower()
    message_text = " ".join(context.args[1:])
    
    if channel_name not in CHANNELS:
        await update.message.reply_text(f"❌ Channel '{channel_name}' not found!")
        return
    
    try:
        await context.bot.send_message(
            chat_id=CHANNELS[channel_name],
            text=f"📢 {message_text}\n\n*(Sent by bot)*",
            parse_mode="Markdown"
        )
        await update.message.reply_text(f"✅ Message posted to {channel_name}!")
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")
        logger.error(f"Error posting to {channel_name}: {e}")

# ============ FORWARDING HANDLER ============

async def forward_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/forward <from_channel> <to_channel> - Forward latest message"""
    if len(context.args) != 2:
        await update.message.reply_text(
            "❌ Usage: /forward <from_channel> <to_channel>\n"
            "Example: /forward news updates"
        )
        return
    
    from_channel = context.args[0].lower()
    to_channel = context.args[1].lower()
    
    if from_channel not in CHANNELS or to_channel not in CHANNELS:
        await update.message.reply_text("❌ Invalid channel name!")
        return
    
    try:
        await update.message.reply_text(f"⏳ Forwarding from {from_channel} to {to_channel}...")
        # Note: This is a simplified example. In production, you'd store message IDs
        await update.message.reply_text(
            f"✅ Forward setup complete!\n"
            f"Messages from {from_channel} → {to_channel}"
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

# ============ SCHEDULING HANDLER ============

async def schedule_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/schedule <seconds> <text> - Schedule a message"""
    if len(context.args) < 2:
        await update.message.reply_text("❌ Usage: /schedule <seconds> <message>")
        return
    
    try:
        delay = int(context.args[0])
        message_text = " ".join(context.args[1:])
    except ValueError:
        await update.message.reply_text("❌ First argument must be a number (seconds)")
        return
    
    if delay < 1:
        await update.message.reply_text("❌ Delay must be at least 1 second")
        return
    
    # Schedule job using JobQueue
    context.job_queue.run_once(
        send_scheduled_message,
        delay=delay,
        data={"chat_id": update.effective_chat.id, "text": message_text},
        name=f"scheduled_{update.effective_user.id}_{datetime.now().timestamp()}"
    )
    
    await update.message.reply_text(
        f"⏰ Message scheduled!\n"
        f"Will send in {delay} seconds: {message_text}"
    )

async def send_scheduled_message(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Callback for scheduled messages"""
    job = context.job
    chat_id = job.data["chat_id"]
    text = job.data["text"]
    
    try:
        await context.bot.send_message(
            chat_id=chat_id,
            text=f"⏰ *Scheduled Message:*\n{text}",
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Error sending scheduled message: {e}")

# ============ MESSAGE HANDLER ============

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle regular messages - can add auto-forwarding logic here"""
    logger.info(f"Message received: {update.message.text}")
    # Add your custom logic here
    # Example: Auto-forward certain types of messages

# ============ ERROR HANDLER ============

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log errors"""
    logger.error(msg="Exception while handling an update:", exc_info=context.error)

# ============ MAIN APPLICATION ============

def main() -> None:
    """Start the bot"""
    # Replace with your actual token
    TOKEN = "YOUR_BOT_TOKEN_HERE"
    
    # Create the Application
    application = Application.builder().token(TOKEN).build()
    
    # Add command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("list_channels", list_channels))
    application.add_handler(CommandHandler("post", post_to_all))
    application.add_handler(CommandHandler("post_channel", post_to_channel))
    application.add_handler(CommandHandler("forward", forward_message_handler))
    application.add_handler(CommandHandler("schedule", schedule_message))
    
    # Add message handler (for other messages)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Add error handler
    application.add_error_handler(error_handler)
    
    # Start the bot
    print("🤖 Bot started! Press Ctrl+C to stop.")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()