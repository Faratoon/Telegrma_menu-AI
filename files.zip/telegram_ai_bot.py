import logging
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
import google.generativeai as genai

# Configure logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ============ CONFIGURATION ============

TELEGRAM_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"  # Get from @BotFather
GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"      # Get from https://makersuite.google.com/app/apikeys

# Configure Gemini API
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-pro')

# Store conversation history per user
user_conversations = {}

# ============ STATES ============
MENU = 0
CHAT = 1
TYPING = 2

# ============ MAIN MENU ============

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Display main menu with inline buttons"""
    
    keyboard = [
        [
            InlineKeyboardButton("💬 AI Chat", callback_data="ai_chat"),
            InlineKeyboardButton("📝 Creative Writing", callback_data="creative_write"),
        ],
        [
            InlineKeyboardButton("🔍 Ask Question", callback_data="ask_question"),
            InlineKeyboardButton("📚 Summarize", callback_data="summarize"),
        ],
        [
            InlineKeyboardButton("🎓 Explain Topic", callback_data="explain_topic"),
            InlineKeyboardButton("💡 Get Ideas", callback_data="get_ideas"),
        ],
        [
            InlineKeyboardButton("✍️ Code Helper", callback_data="code_helper"),
            InlineKeyboardButton("🌍 Translate", callback_data="translate"),
        ],
        [
            InlineKeyboardButton("📊 Analyze", callback_data="analyze"),
            InlineKeyboardButton("⚙️ Settings", callback_data="settings"),
        ],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_text = """
🤖 **Welcome to AI Chat Bot!**

Powered by Google Gemini AI

I can help you with:
✅ Answer questions
✅ Creative writing
✅ Code help
✅ Summarization
✅ Translation
✅ And much more!

Choose an option below:
    """
    
    if update.message:
        await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode="Markdown")
    else:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(welcome_text, reply_markup=reply_markup, parse_mode="Markdown")
    
    return MENU

# ============ GEMINI AI FUNCTION ============

def get_ai_response(user_id: int, user_message: str, mode: str = "normal") -> str:
    """Get response from Gemini AI"""
    
    try:
        # Get or create conversation history
        if user_id not in user_conversations:
            user_conversations[user_id] = []
        
        # Add user message to history
        user_conversations[user_id].append({
            "role": "user",
            "message": user_message
        })
        
        # Build context based on mode
        context_prompt = ""
        if mode == "creative_write":
            context_prompt = "You are a creative writing assistant. "
        elif mode == "code_helper":
            context_prompt = "You are a helpful programming expert. Provide code examples when relevant. "
        elif mode == "translate":
            context_prompt = "You are a translation expert. "
        elif mode == "summarize":
            context_prompt = "You are a summarization expert. Provide concise summaries. "
        elif mode == "explain_topic":
            context_prompt = "You are an expert educator. Explain topics clearly. "
        
        # Create conversation context
        conversation_text = context_prompt + "\n\n"
        for item in user_conversations[user_id][-5:]:  # Keep last 5 messages for context
            conversation_text += f"{item['role'].capitalize()}: {item['message']}\n"
        
        # Get response from Gemini
        response = model.generate_content(conversation_text)
        ai_response = response.text
        
        # Add AI response to history
        user_conversations[user_id].append({
            "role": "assistant",
            "message": ai_response
        })
        
        return ai_response
    
    except Exception as e:
        logger.error(f"Error getting AI response: {e}")
        return f"❌ Error: {str(e)}"

# ============ MENU BUTTON HANDLERS ============

async def ai_chat(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle AI Chat button"""
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    user_conversations[user_id] = []  # Reset conversation
    
    context.user_data["mode"] = "normal"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
💬 **AI Chat Mode**

Type your message and I'll respond using AI!
(I remember our conversation)

Send me any message to chat:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHAT

async def creative_write(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Creative Writing button"""
    query = update.callback_query
    await query.answer()
    
    context.user_data["mode"] = "creative_write"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
✍️ **Creative Writing Mode**

I can help you with:
• Story writing
• Poetry
• Character development
• Plot ideas
• Dialogue writing

Send me your writing request:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHAT

async def ask_question(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Ask Question button"""
    query = update.callback_query
    await query.answer()
    
    context.user_data["mode"] = "normal"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
🔍 **Ask Any Question**

Ask me anything and I'll try to help!

Send your question:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHAT

async def summarize(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Summarize button"""
    query = update.callback_query
    await query.answer()
    
    context.user_data["mode"] = "summarize"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
📚 **Summarize Text**

Paste text or write what you want me to summarize:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHAT

async def explain_topic(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Explain Topic button"""
    query = update.callback_query
    await query.answer()
    
    context.user_data["mode"] = "explain_topic"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
🎓 **Explain a Topic**

Tell me what topic you'd like me to explain:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHAT

async def get_ideas(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Get Ideas button"""
    query = update.callback_query
    await query.answer()
    
    context.user_data["mode"] = "normal"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
💡 **Get Ideas**

I can help brainstorm ideas for:
• Blog posts
• Projects
• Business ideas
• Content creation
• Problem solving

Tell me what you need ideas for:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHAT

async def code_helper(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Code Helper button"""
    query = update.callback_query
    await query.answer()
    
    context.user_data["mode"] = "code_helper"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
✍️ **Code Helper**

I can help with:
• Writing code
• Debugging
• Code explanation
• Best practices
• Algorithm help

Ask your coding question:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHAT

async def translate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Translate button"""
    query = update.callback_query
    await query.answer()
    
    context.user_data["mode"] = "translate"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
🌍 **Translate**

Tell me:
1. What language you want to translate to
2. The text to translate

Example: "Translate to Spanish: Hello world"
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHAT

async def analyze(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Analyze button"""
    query = update.callback_query
    await query.answer()
    
    context.user_data["mode"] = "normal"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
📊 **Analyze**

I can analyze:
• Text/documents
• Data
• Arguments
• Trends
• Sentiment

Send me what you want analyzed:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHAT

async def settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Settings button"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("🗑️ Clear Chat History", callback_data="clear_history")],
        [InlineKeyboardButton("ℹ️ About", callback_data="about")],
        [InlineKeyboardButton("⬅️ Back to Menu", callback_data="back_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
⚙️ **Settings**

Configure your preferences:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return MENU

async def clear_history(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Clear user's conversation history"""
    query = update.callback_query
    await query.answer("Chat history cleared! ✅")
    
    user_id = update.effective_user.id
    if user_id in user_conversations:
        user_conversations[user_id] = []
    
    await query.edit_message_text("✅ Chat history cleared!\n\nGoing back to menu...")
    return await start(update, context)

async def about(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Show about information"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="settings")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
ℹ️ **About This Bot**

🤖 AI Chat Bot v1.0
Powered by Google Gemini AI

Features:
✅ AI Chat with conversation memory
✅ Creative writing assistance
✅ Code help
✅ Text summarization
✅ Translation
✅ Data analysis

Created to help you with AI!
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return MENU

# ============ HANDLE USER MESSAGES ============

async def handle_user_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle user text input and get AI response"""
    
    user_id = update.effective_user.id
    user_message = update.message.text
    mode = context.user_data.get("mode", "normal")
    
    # Show typing indicator
    await update.message.chat.send_action("typing")
    
    # Get AI response
    response = get_ai_response(user_id, user_message, mode)
    
    # Split long messages (Telegram limit is 4096 characters)
    if len(response) > 4096:
        parts = [response[i:i+4096] for i in range(0, len(response), 4096)]
        for part in parts:
            await update.message.reply_text(part, parse_mode="Markdown")
    else:
        await update.message.reply_text(response, parse_mode="Markdown")
    
    return CHAT

async def back_to_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Go back to main menu"""
    return await start(update, context)

# ============ ERROR HANDLER ============

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log errors"""
    logger.error(msg="Exception while handling an update:", exc_info=context.error)
    
    if update and hasattr(update, 'message'):
        await update.message.reply_text(
            "❌ An error occurred. Please try again later."
        )

# ============ MAIN FUNCTION ============

def main() -> None:
    """Start the bot"""
    
    # Create Application
    application = Application.builder().token(TELEGRAM_TOKEN).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start))
    
    # Menu button handlers
    application.add_handler(CallbackQueryHandler(back_to_menu, pattern="^back_menu$"))
    application.add_handler(CallbackQueryHandler(ai_chat, pattern="^ai_chat$"))
    application.add_handler(CallbackQueryHandler(creative_write, pattern="^creative_write$"))
    application.add_handler(CallbackQueryHandler(ask_question, pattern="^ask_question$"))
    application.add_handler(CallbackQueryHandler(summarize, pattern="^summarize$"))
    application.add_handler(CallbackQueryHandler(explain_topic, pattern="^explain_topic$"))
    application.add_handler(CallbackQueryHandler(get_ideas, pattern="^get_ideas$"))
    application.add_handler(CallbackQueryHandler(code_helper, pattern="^code_helper$"))
    application.add_handler(CallbackQueryHandler(translate, pattern="^translate$"))
    application.add_handler(CallbackQueryHandler(analyze, pattern="^analyze$"))
    application.add_handler(CallbackQueryHandler(settings, pattern="^settings$"))
    application.add_handler(CallbackQueryHandler(clear_history, pattern="^clear_history$"))
    application.add_handler(CallbackQueryHandler(about, pattern="^about$"))
    
    # Message handler for user input during chat
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_user_input))
    
    # Error handler
    application.add_error_handler(error_handler)
    
    # Start bot
    print("🤖 AI Chat Bot Started!")
    print("Press Ctrl+C to stop")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()