import logging
import os
import json
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
import google.generativeai as genai

# ============ SETUP ============
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Import config
from config.settings import TELEGRAM_TOKEN, GEMINI_API_KEY, CHANNELS

# Configure Gemini
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-pro')

# ============ DATA STORAGE ============
user_conversations = {}
user_posts = {}
user_settings = {}

# ============ STATES ============
MENU, CHAT_MODE, POST_MODE, CHANNEL_MODE, SCHEDULE_MODE = range(5)

# ============ MAIN MENU ============

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Display main menu"""
    
    keyboard = [
        [
            InlineKeyboardButton("💬 AI Chat", callback_data="ai_chat"),
            InlineKeyboardButton("📝 Create Posts", callback_data="create_posts"),
        ],
        [
            InlineKeyboardButton("📢 Multipost", callback_data="multipost"),
            InlineKeyboardButton("📤 Forward", callback_data="forward"),
        ],
        [
            InlineKeyboardButton("⏰ Schedule", callback_data="schedule_post"),
            InlineKeyboardButton("🎓 Learning", callback_data="ai_learning"),
        ],
        [
            InlineKeyboardButton("🔍 Ask AI", callback_data="ask_ai"),
            InlineKeyboardButton("✍️ Writing", callback_data="ai_writing"),
        ],
        [
            InlineKeyboardButton("📊 Channels", callback_data="manage_channels"),
            InlineKeyboardButton("⚙️ Settings", callback_data="settings"),
        ],
        [
            InlineKeyboardButton("❓ Help", callback_data="help"),
        ],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
🤖 **ALL-IN-ONE TELEGRAM BOT**

Dhamaantood isku noqdaan bot mid:
✅ AI Chat (Gemini)
✅ Channel Management
✅ Post Creation & AI Generation
✅ Message Forwarding
✅ Post Scheduling
✅ Creative Writing
✅ Learning & Q&A

Choose what you need:
    """
    
    if update.message:
        await update.message.reply_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    else:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    
    return MENU

# ============ AI FUNCTIONS ============

def get_ai_response(user_id: int, message: str, mode: str = "chat") -> str:
    """Get AI response from Gemini"""
    try:
        if user_id not in user_conversations:
            user_conversations[user_id] = []
        
        context = ""
        if mode == "learning":
            context = "You are an expert educator. Explain topics clearly and educatingly. "
        elif mode == "writing":
            context = "You are a creative writing expert. Help with creative content. "
        elif mode == "coding":
            context = "You are a programming expert. Provide code examples. "
        
        convo_text = context
        for item in user_conversations[user_id][-5:]:
            convo_text += f"{item['role']}: {item['message']}\n"
        convo_text += f"user: {message}\n"
        
        response = model.generate_content(convo_text)
        ai_text = response.text
        
        user_conversations[user_id].append({"role": "user", "message": message})
        user_conversations[user_id].append({"role": "assistant", "message": ai_text})
        
        return ai_text
    
    except Exception as e:
        logger.error(f"AI Error: {e}")
        return f"❌ Error: {str(e)}"

# ============ AI CHAT MODES ============

async def ai_chat_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """AI Chat"""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    user_conversations[user_id] = []
    context.user_data["mode"] = "chat"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="back_menu")]]
    await query.edit_message_text(
        "💬 **AI Chat Mode**\n\nType your message:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return CHAT_MODE

async def ai_learning(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Learning mode"""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    user_conversations[user_id] = []
    context.user_data["mode"] = "learning"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="back_menu")]]
    await query.edit_message_text(
        "🎓 **Learning Mode**\n\nBar cid runta ah, ask me to teach:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return CHAT_MODE

async def ask_ai(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Ask questions"""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    user_conversations[user_id] = []
    context.user_data["mode"] = "chat"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="back_menu")]]
    await query.edit_message_text(
        "🔍 **Ask AI Anything**\n\nAsk your question:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return CHAT_MODE

async def ai_writing(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Creative writing"""
    query = update.callback_query
    await query.answer()
    user_id = update.effective_user.id
    user_conversations[user_id] = []
    context.user_data["mode"] = "writing"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="back_menu")]]
    await query.edit_message_text(
        "✍️ **Creative Writing**\n\nSend your writing request:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return CHAT_MODE

# ============ CHAT INPUT HANDLER ============

async def handle_chat_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle chat messages"""
    
    user_id = update.effective_user.id
    mode = context.user_data.get("mode", "chat")
    
    await update.message.chat.send_action("typing")
    response = get_ai_response(user_id, update.message.text, mode)
    
    if len(response) > 4096:
        parts = [response[i:i+4096] for i in range(0, len(response), 4096)]
        for part in parts:
            await update.message.reply_text(part, parse_mode="Markdown")
    else:
        await update.message.reply_text(response, parse_mode="Markdown")
    
    return CHAT_MODE

# ============ POST CREATION ============

async def create_posts(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Create posts menu"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("📝 Write Post", callback_data="write_post")],
        [InlineKeyboardButton("🤖 AI Generate", callback_data="ai_generate_post")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
    ]
    
    await query.edit_message_text(
        "📝 **Create Posts**\n\nHow do you want to create:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return POST_MODE

async def write_post(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Write post manually"""
    query = update.callback_query
    await query.answer()
    context.user_data["post_action"] = "write"
    
    keyboard = [[InlineKeyboardButton("⬅️ Cancel", callback_data="back_menu")]]
    await query.edit_message_text(
        "✍️ **Write Your Post**\n\nType the content:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return POST_MODE

async def ai_generate_post(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Generate post using AI"""
    query = update.callback_query
    await query.answer()
    context.user_data["post_action"] = "ai_generate"
    
    keyboard = [[InlineKeyboardButton("⬅️ Cancel", callback_data="back_menu")]]
    await query.edit_message_text(
        "🤖 **AI Generate Post**\n\nTell me what post you want:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return POST_MODE

# ============ CHANNEL MANAGEMENT ============

async def manage_channels(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Manage channels"""
    query = update.callback_query
    await query.answer()
    
    channels_text = "📊 **Your Channels:**\n\n"
    for name, channel_id in CHANNELS.items():
        channels_text += f"• {name.upper()}: `{channel_id}`\n"
    
    keyboard = [
        [InlineKeyboardButton("➕ Add", callback_data="add_channel")],
        [InlineKeyboardButton("➖ Remove", callback_data="remove_channel")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
    ]
    
    await query.edit_message_text(
        channels_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return CHANNEL_MODE

# ============ MULTIPOST ============

async def multipost(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Post to multiple channels"""
    query = update.callback_query
    await query.answer()
    
    keyboard = []
    for channel_name in CHANNELS.keys():
        keyboard.append([InlineKeyboardButton(f"✓ {channel_name.upper()}", callback_data=f"select_{channel_name}")])
    keyboard.append([InlineKeyboardButton("✅ Post", callback_data="post_selected")])
    keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="back_menu")])
    
    await query.edit_message_text(
        "📢 **Multipost**\n\nSelect channels:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return MENU

# ============ FORWARD MESSAGES ============

async def forward_messages(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Forward between channels"""
    query = update.callback_query
    await query.answer()
    
    keyboard = []
    for channel_name in CHANNELS.keys():
        keyboard.append([InlineKeyboardButton(f"From: {channel_name}", callback_data=f"forward_from_{channel_name}")])
    keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="back_menu")])
    
    await query.edit_message_text(
        "📤 **Forward Messages**\n\nSelect source:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return MENU

# ============ SCHEDULE POST ============

async def schedule_post_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Schedule post"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("30 sec", callback_data="delay_30")],
        [InlineKeyboardButton("5 min", callback_data="delay_300")],
        [InlineKeyboardButton("1 hour", callback_data="delay_3600")],
        [InlineKeyboardButton("Custom", callback_data="delay_custom")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
    ]
    
    await query.edit_message_text(
        "⏰ **Schedule Post**\n\nWhen to send:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return SCHEDULE_MODE

# ============ SETTINGS ============

async def settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Settings"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("🗑️ Clear History", callback_data="clear_history")],
        [InlineKeyboardButton("ℹ️ About", callback_data="about")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
    ]
    
    await query.edit_message_text(
        "⚙️ **Settings**",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return MENU

async def clear_history(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Clear chat history"""
    query = update.callback_query
    await query.answer("✅ History cleared!")
    
    user_id = update.effective_user.id
    if user_id in user_conversations:
        user_conversations[user_id] = []
    
    return await start(update, context)

# ============ HELP ============

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Help"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="back_menu")]]
    
    text = """
❓ **Help & Features**

**AI Features:**
💬 Chat with AI (Gemini)
🎓 Learning mode
🔍 Ask questions
✍️ Creative writing

**Channel Features:**
📝 Create posts
🤖 AI generate posts
📢 Post to multiple channels
📤 Forward messages
⏰ Schedule posts
📊 Manage channels

**How to use:**
1. Choose option from menu
2. Follow instructions
3. Send content
4. Done! ✅
    """
    
    await query.edit_message_text(
        text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return MENU

# ============ CALLBACK HANDLER ============

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle all buttons"""
    query = update.callback_query
    data = query.data
    
    handlers = {
        "back_menu": start,
        "ai_chat": ai_chat_mode,
        "ai_learning": ai_learning,
        "ask_ai": ask_ai,
        "ai_writing": ai_writing,
        "create_posts": create_posts,
        "write_post": write_post,
        "ai_generate_post": ai_generate_post,
        "multipost": multipost,
        "forward": forward_messages,
        "schedule_post": schedule_post_mode,
        "manage_channels": manage_channels,
        "settings": settings,
        "clear_history": clear_history,
        "help": help_command,
    }
    
    handler = handlers.get(data)
    if handler:
        return await handler(update, context)
    
    return MENU

# ============ ERROR HANDLER ============

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle errors"""
    logger.error(msg="Exception:", exc_info=context.error)

# ============ MAIN ============

def main() -> None:
    """Start bot"""
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_chat_input))
    app.add_error_handler(error_handler)
    
    logger.info("🚀 BOT STARTED!")
    print("=" * 50)
    print("🤖 ALL-IN-ONE TELEGRAM BOT")
    print("=" * 50)
    print("✅ AI Chat")
    print("✅ Channel Management")
    print("✅ Post Creation")
    print("✅ Message Forwarding")
    print("✅ Post Scheduling")
    print("=" * 50)
    print("Press Ctrl+C to stop")
    
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()