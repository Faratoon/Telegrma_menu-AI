import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ConversationHandler,
    filters,
    ContextTypes,
)
from datetime import datetime, timedelta
import json

# Enable logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ============ STATES FOR CONVERSATIONS ============
CHOOSING, TYPING_POST, SELECTING_CHANNEL, TYPING_DELAY, SELECTING_SOURCE, SELECTING_TARGET = range(6)

# Configure your channels
CHANNELS = {
    "news": -1001234567890,
    "updates": -1001234567891,
    "announcements": -1001234567892,
}

# ============ MAIN MENU ============

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Display the main menu with inline buttons"""
    
    keyboard = [
        [
            InlineKeyboardButton("📝 Create posts", callback_data="create_posts"),
            InlineKeyboardButton("📤 My posts", callback_data="my_posts"),
        ],
        [
            InlineKeyboardButton("📢 Multipost", callback_data="multipost"),
            InlineKeyboardButton("⚙️ Auto-complete", callback_data="autocomplete"),
        ],
        [
            InlineKeyboardButton("🔔 Welcome", callback_data="welcome"),
            InlineKeyboardButton("👋 Goodbye", callback_data="goodbye"),
        ],
        [
            InlineKeyboardButton("📋 Event log", callback_data="event_log"),
            InlineKeyboardButton("🔗 Join filters", callback_data="join_filters"),
        ],
        [
            InlineKeyboardButton("📤 Forward", callback_data="forward"),
            InlineKeyboardButton("🌍 Languages", callback_data="languages"),
        ],
        [
            InlineKeyboardButton("⭐ Subscription", callback_data="subscription"),
            InlineKeyboardButton("⚙️ Settings", callback_data="settings"),
        ],
        [
            InlineKeyboardButton("🤖 Create bot", callback_data="create_bot"),
            InlineKeyboardButton("❓ Support", callback_data="support"),
        ],
        [
            InlineKeyboardButton("📚 Guide", callback_data="guide"),
        ],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_text = """
🎉 **Welcome to Channel Manager Bot!**

Manage multiple Telegram channels with ease:
✅ Create and schedule posts
✅ Forward messages between channels
✅ Send and delete posts on chosen dates
✅ Welcome new subscribers
✅ Share posts with anyone you want
...And much more!

Select an option below:
    """
    
    if update.message:
        await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode="Markdown")
    else:
        await update.callback_query.edit_message_text(welcome_text, reply_markup=reply_markup, parse_mode="Markdown")
    
    return CHOOSING

# ============ BUTTON HANDLERS ============

async def create_posts(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Create posts button"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("📝 Write new post", callback_data="write_post")],
        [InlineKeyboardButton("⏰ Schedule post", callback_data="schedule_post")],
        [InlineKeyboardButton("🔗 Add link buttons", callback_data="add_buttons")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    text = """
📝 **Create Posts**

Choose what you want to do:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHOOSING

async def write_post(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Get post content from user"""
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text(
        "✍️ **Write your post message:**\n\nSend me the content you want to post:",
        parse_mode="Markdown"
    )
    
    context.user_data["action"] = "write_post"
    return TYPING_POST

async def schedule_post(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Schedule a post"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("30 seconds", callback_data="delay_30")],
        [InlineKeyboardButton("1 minute", callback_data="delay_60")],
        [InlineKeyboardButton("5 minutes", callback_data="delay_300")],
        [InlineKeyboardButton("Custom time", callback_data="delay_custom")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    text = """
⏰ **Schedule Post**

When should this post be sent?
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHOOSING

async def add_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Add link buttons to post"""
    query = update.callback_query
    await query.answer()
    
    await query.edit_message_text(
        "🔗 **Add Link Buttons**\n\n"
        "Send button data in format:\n"
        "`Button Text|https://example.com`\n\n"
        "Example:\n"
        "`Click here|https://google.com`",
        parse_mode="Markdown"
    )
    
    context.user_data["action"] = "add_buttons"
    return TYPING_POST

async def multipost(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Multipost - post to multiple channels"""
    query = update.callback_query
    await query.answer()
    
    # List all channels
    channels_text = "📢 **Select Channels for Multipost:**\n\n"
    keyboard = []
    
    for channel_name in CHANNELS.keys():
        channels_text += f"• {channel_name}\n"
        keyboard.append([InlineKeyboardButton(f"✓ {channel_name}", callback_data=f"select_{channel_name}")])
    
    keyboard.append([InlineKeyboardButton("✅ Post to selected", callback_data="post_selected")])
    keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="back_menu")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(channels_text, reply_markup=reply_markup, parse_mode="Markdown")
    context.user_data["selected_channels"] = []
    return CHOOSING

async def forward_messages(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Forward button"""
    query = update.callback_query
    await query.answer()
    
    channels_text = "📤 **Forward Messages**\n\nSelect source channel:\n"
    keyboard = []
    
    for channel_name in CHANNELS.keys():
        keyboard.append([InlineKeyboardButton(f"From: {channel_name}", callback_data=f"forward_from_{channel_name}")])
    
    keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="back_menu")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(channels_text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHOOSING

async def welcome(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Welcome button"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("✏️ Edit welcome message", callback_data="edit_welcome")],
        [InlineKeyboardButton("✅ Enable", callback_data="enable_welcome")],
        [InlineKeyboardButton("❌ Disable", callback_data="disable_welcome")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    text = """
🔔 **Welcome New Subscribers**

Automatically send a welcome message when users join your channel.
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHOOSING

async def settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Settings button"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("➕ Add channel", callback_data="add_channel")],
        [InlineKeyboardButton("➖ Remove channel", callback_data="remove_channel")],
        [InlineKeyboardButton("📊 View channels", callback_data="view_channels")],
        [InlineKeyboardButton("🔐 Privacy", callback_data="privacy")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    text = """
⚙️ **Settings**

Configure your bot and channels:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHOOSING

async def view_channels(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """View all configured channels"""
    query = update.callback_query
    await query.answer()
    
    channels_text = "📊 **Your Channels:**\n\n"
    for name, channel_id in CHANNELS.items():
        channels_text += f"• {name.capitalize()}: `{channel_id}`\n"
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="settings")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(channels_text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHOOSING

async def support(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Support button"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("💬 Contact support", url="https://t.me/support")],
        [InlineKeyboardButton("📖 FAQ", url="https://example.com/faq")],
        [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    text = """
❓ **Support & Help**

Need help? Choose an option:
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHOOSING

async def guide(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle Guide button"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="back_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = """
📚 **User Guide**

**Getting Started:**
1️⃣ Add your channels in Settings
2️⃣ Create posts using Create Posts
3️⃣ Schedule or post immediately
4️⃣ Use Multipost for multiple channels

**Features:**
• Schedule posts for specific times
• Forward messages between channels
• Auto-welcome new subscribers
• Add clickable buttons to posts
• Manage multiple channels easily

**Tips:**
💡 Use keyboard shortcuts
💡 Set up welcome messages
💡 Schedule posts in advance
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode="Markdown")
    return CHOOSING

async def back_to_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Go back to main menu"""
    return await start(update, context)

# ============ HANDLE TEXT INPUT ============

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle text input from user"""
    action = context.user_data.get("action")
    
    if action == "write_post":
        context.user_data["post_content"] = update.message.text
        
        keyboard = [
            [InlineKeyboardButton("📍 Select channel", callback_data="select_channel_post")],
            [InlineKeyboardButton("📲 Preview", callback_data="preview_post")],
            [InlineKeyboardButton("✅ Post now", callback_data="post_now")],
            [InlineKeyboardButton("⬅️ Back", callback_data="back_menu")],
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        text = f"""
✅ **Post saved!**

Your post: