"""
Configuration settings for the bot
Edit this file to customize your bot!
"""

# ============ TOKENS & KEYS ============
TELEGRAM_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"  # From @BotFather
GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"      # From makersuite.google.com

# ============ CHANNELS ============
CHANNELS = {
    "news": -1001234567890,
    "updates": -1001234567891,
    "announcements": -1001234567892,
}

# ============ BOT SETTINGS ============
BOT_NAME = "ALL-IN-ONE BOT"
BOT_VERSION = "1.0.0"
LOG_FILE = "logs/bot.log"

# ============ TIMEOUTS ============
REQUEST_TIMEOUT = 30
CONNECT_TIMEOUT = 30

# ============ FEATURES ============
FEATURES = {
    "ai_chat": True,
    "post_creation": True,
    "multipost": True,
    "forwarding": True,
    "scheduling": True,
    "learning_mode": True,
    "creative_writing": True,
}

# ============ AI SETTINGS ============
AI_MODEL = "gemini-pro"
MAX_CONVERSATION_LENGTH = 5  # Keep last 5 messages for context